using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            durum.Text = "0";

            var ports = SerialPort.GetPortNames();
            comboBox1.DataSource = ports;

            comboBox2.Items.AddRange(new string[] {"4800", "9600", "115200" });

            var databids = new string[] { "1", "2", "3", "4", "5", "6", "7", "8", };
            comboBox3.Items.AddRange(databids);

            button2.Enabled = false;
        }
        public int paketl = 0;
        public int kay�p = 0;
        public int espak = 0;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                string data = (serialPort1.ReadExisting());
                if (data.StartsWith("#"))
                {
                    paketl++;
                    string[] pack1 = data.Split(',');

                    textBox1.Text = pack1[1].ToString();
                    listBox1.Items.Add(textBox1.Text);

                    textBox2.Text = pack1[2].ToString();
                    listBox2.Items.Add(textBox2.Text);

                    textBox3.Text = pack1[3].ToString();
                    listBox3.Items.Add(textBox3.Text);

                    textBox4.Text = pack1[4].ToString();
                    listBox4.Items.Add(textBox4.Text);

                    textBox5.Text = pack1[5].ToString();
                    listBox5.Items.Add(textBox5.Text);

                    textBox6.Text = pack1[6].ToString();
                    listBox6.Items.Add(textBox6.Text);

                    textBox7.Text = pack1[7].ToString();
                    listBox7.Items.Add(textBox7.Text);

                    textBox8.Text = pack1[8].ToString();
                    listBox8.Items.Add(textBox8.Text);

                    textBox9.Text = pack1[9].ToString();
                    listBox9.Items.Add(textBox9.Text);

                    textBox10.Text = pack1[10].ToString();
                    listBox10.Items.Add(textBox10.Text);

                    textBox11.Text = pack1[11].ToString();
                    listBox11.Items.Add(textBox11.Text);

                    textBox12.Text = pack1[12].ToString();
                    listBox12.Items.Add(textBox12.Text);

                    textBox13.Text = pack1[13].ToString();
                    listBox13.Items.Add(textBox13.Text);

                    textBox14.Text = pack1[14].ToString();
                    listBox14.Items.Add(textBox14.Text);

                    textBox15.Text = pack1[15].ToString();
                    listBox15.Items.Add(textBox15.Text);

                    textBox16.Text = pack1[16].ToString();
                    listBox16.Items.Add(textBox16.Text);

                    textBox17.Text = pack1[17].ToString();
                    listBox17.Items.Add(textBox17.Text);

                    textBox18.Text = pack1[18].ToString();
                    listBox18.Items.Add(textBox18.Text);

                    textBox19.Text = pack1[19].ToString();
                    listBox19.Items.Add(textBox19.Text);

                    textBox20.Text = pack1[20].ToString();
                    listBox20.Items.Add(textBox20.Text);

                    textBox21.Text = pack1[21].ToString();
                    listBox21.Items.Add(textBox21.Text);

                    textBox22.Text = pack1[22].ToString();
                    listBox22.Items.Add(textBox22.Text);

                    textBox23.Text = pack1[23].ToString();
                    listBox23.Items.Add(textBox23.Text);

                    textBox24.Text = pack1[24].ToString();
                    listBox24.Items.Add(textBox24.Text);

                    textBox25.Text = pack1[25].ToString();
                    listBox25.Items.Add(textBox25.Text);

                    textBox26.Text = pack1[26].ToString();
                    listBox26.Items.Add(textBox26.Text);

//gireceksen

                    kay�p = Math.Abs(paketl - Convert.ToInt16(pack1[17]));
                    espak = Convert.ToInt16(pack1[17]);
                }
                kaypak.Text = kay�p.ToString();
                esppak.Text = espak.ToString();
                sonpak.Text = paketl.ToString();
            }
            catch (Exception ex)
            {

            }

}

        private void button1_Click(object sender, EventArgs e)
        {
            durum.Text = "Ba�lan�yor";
            timer1.Start();
            try
            {
                serialPort1.PortName = comboBox1.Text;
                serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text);
                serialPort1.DataBits = Convert.ToInt16(comboBox3.Text);


                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                    durum.Text = "Ba�lant� Var";
                }

                if (serialPort1.IsOpen)
                {
                    button1.Enabled = false;
                    button2.Enabled = true;
                }
                paketl = 0;
                serialPort1.WriteLine("1");
            }
            catch (Exception)
            {
                durum.Text = "Ba�lant� Yok";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            serialPort1.Close();
            durum.Text = "Ba�lant� Kesildi";
            button1.Enabled = true;
            button2.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox7.Items.Clear();
            listBox8.Items.Clear();
            listBox9.Items.Clear();
            listBox10.Items.Clear();
            listBox11.Items.Clear();
            listBox12.Items.Clear();
            listBox13.Items.Clear();
            listBox14.Items.Clear();
            listBox15.Items.Clear();
            listBox16.Items.Clear();
            listBox17.Items.Clear();
            listBox18.Items.Clear();
            listBox19.Items.Clear();
            listBox20.Items.Clear();
            listBox21.Items.Clear();
            listBox22.Items.Clear();
            listBox23.Items.Clear();
            listBox24.Items.Clear();
            listBox25.Items.Clear();
            listBox26.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox17.Clear();
            textBox18.Clear();
            textBox19.Clear();
            textBox20.Clear();
            textBox21.Clear();
            textBox22.Clear();
            textBox23.Clear();
            textBox24.Clear();
            textBox25.Clear();
            textBox26.Clear();
        }

        private void listBox25_SelectedIndexChanged(object sender, EventArgs e)
        {

        }